<?php

function nut_parser($input)
{
	
	$input = htmlentities($input);
	
	
	$search = array (
		'/\!:(.*?):!/',
		'/\@:(.*?):@/',
		'/\#:(.*?):#/',
		'/\.:(.*?):./'
		
		);
	$replace = array(
		'<a href="$1">$1</a>',
		'<img src="$1">',
		'<b>$1</b>',
		'<i>$1</i>'
		
	);
	
	return preg_replace($search, $replace, $input);
	
}
?>